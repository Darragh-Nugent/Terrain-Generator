class Colour {
    R;
    G;
    B;
    A;

    constructor(R, G, B, A = 0)
    {      
        this.R = R;
        this.G = G;
        this.B = B;
        this.A = A;
    }
}

module.exports = Person;