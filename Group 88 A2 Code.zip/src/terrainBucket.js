const S3 = require("@aws-sdk/client-s3");

const bucketName = process.env.S3_BUCKET
const qut_username = 'n11547227@qut.edu.au'
const qut_username2 = 'n11596708@qut.edu.au'
const purpose = 'assessment 2'

async function CreateBucket() {
    s3Client = new S3.S3Client({ region: 'ap-southeast-2' });

    try {
    const createResp = await s3Client.send(
      new S3.CreateBucketCommand({ Bucket: bucketName })
    );
    console.log("Bucket created:", createResp.Location);

    const tagResp = await s3Client.send(
      new S3.PutBucketTaggingCommand({
        Bucket: bucketName,
        Tagging: {
          TagSet: [
            { Key: "qut-username", Value: qut_username },
            { Key: "qut-username2", Value: qut_username2 },
            { Key: "purpose", Value: purpose },
          ],
        },
      })
    );
    console.log("Tags applied:", tagResp);
  } catch (err) {
    if (err.name === "BucketAlreadyOwnedByYou") 
      console.log(`Bucket ${bucketName} already exists (owned by you).`);
    
    else
        console.error("Error:", err);
  }
}

(async () => {
    await CreateBucket();
    console.log("Script finished");
})();