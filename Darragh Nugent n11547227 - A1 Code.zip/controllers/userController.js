const User = require("../models/userModels");
const bcrypt = require('bcrypt');

exports.getAllUsers = (req, res) => {
    User.getAll()
    .then(row => {
        if (!row) return res.status(404).json({error: 'Task not found'});
        res.json(row);
    })
    .catch(err => res.status(500).json({error: 'Both names and password is required'}));
};

exports.AddUser = async (req, res) => {
  const {username, password} = req.body;
  if (!username) return res.status(400).json({error: 'Username is required'});
  if (!password) return res.status(400).json({error: 'Password is required'});

  const hash = await bcrypt.hash(password, 10);

  User.AddUser(username, hash)
    .then(user => res.status(201).json(user))
    .catch(err => res.status(500).json({ error: err.message }));

};